﻿# Physical acceptance

Run: C:\Users\_\ASCIIomium\acceptance\runs\20261101-163623-982106
Operator observations only; automated tests are separate.

- PR38 typing: Not tested | 
- PR38 unicode: Not tested | 
- PR38 editing: Not tested | 
- PR38 navigation: Not tested | 
- PR38 focus: Not tested | 
- PR38 modifiers: Not tested | 
- PR38 quit: Not tested | 
- PR38 restoration: Not tested | 
- PR39 centre-corners: Not tested | 
- PR39 hover: Not tested | 
- PR39 press-release: Not tested | 
- PR39 wheel: Not tested | 
- PR39 horizontal-wheel: Not tested | 
- PR39 nested-scroll: Not tested | 
- PR39 resize: Not tested | 
- PR39 letterbox: Not tested | 
- PR39 mouse-modifiers: Not tested | 
- PR39 shift-selection: Not tested | 
- PR39 keyboard-regression: Not tested | 
- PR39 quit: Not tested | 
- PR39 restoration: Not tested | 
