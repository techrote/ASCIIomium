@echo off
wt.exe -w new new-tab --title "ASCIIomium manual launch" -d "%~dp0." powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -NoExit -File "%~dp0acceptance\Start-Manual.ps1"
if errorlevel 1 pause
