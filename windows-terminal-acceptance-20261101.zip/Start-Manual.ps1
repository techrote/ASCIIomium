param([switch]$ValidateOnly)
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
$revisions=@{
 '38'=@{Source=$root;SHA='5f8feccebeb0682890a2023a59b4c33e514c5497'}
 '39'=@{Source=(Join-Path $PSScriptRoot 'source-39');SHA='3aa9b9419dd7936d55bf6acb974f1b0d159f5d95'}
}
function Verify($pr) {
 $target=$revisions[$pr]
 $actual=(& git -C $target.Source rev-parse HEAD).Trim()
 if($LASTEXITCODE -ne 0 -or $actual -ne $target.SHA){throw "PR$pr revision mismatch: $actual"}
 if((& git -C $target.Source status --porcelain --untracked-files=no)){throw "PR$pr has tracked modifications"}
 $exe=Join-Path $root "build-acceptance-$pr\bin\RELEASE\asciiomium_live.exe"
 if(!(Test-Path -LiteralPath $exe)){throw "Missing built executable: $exe"}
 return $exe
}
if($ValidateOnly){foreach($pr in @('38','39')){Verify $pr | Write-Output};return}
if(!$env:WT_SESSION){throw 'Open Start-ASCIIomium.cmd to use Windows Terminal.'}
Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class ManualASCIIomium {
 [DllImport("kernel32.dll")] static extern IntPtr GetStdHandle(int n);
 [DllImport("kernel32.dll")] static extern bool GetConsoleMode(IntPtr h,out uint mode);
 public static int Run(string exe,string args) {
 uint mode;
 if(!GetConsoleMode(GetStdHandle(-10),out mode)||!GetConsoleMode(GetStdHandle(-11),out mode))throw new Exception("Native console stdin/stdout required");
 var p=new System.Diagnostics.Process();
 p.StartInfo=new System.Diagnostics.ProcessStartInfo(exe,args);
 p.StartInfo.UseShellExecute=false;
 p.StartInfo.CreateNoWindow=false;
 // No redirected streams: the browser uses this Terminal's native handles.
 p.Start();p.WaitForExit();return p.ExitCode;
 }
}
'@
while($true){
 Write-Host ''
 Write-Host 'ASCIIomium manual launcher - browser is NOT running.'
 Write-Host 'Adjust Terminal font zoom and resize/maximise this window now.'
 Write-Host 'You can also adjust Terminal font zoom while the browser is running.'
 Write-Host 'Choose PR38 (keyboard) or PR39 (keyboard + mouse). Q closes this menu.'
 $pr=(Read-Host 'Revision: 38 / 39 / Q').Trim()
 if($pr -match '^[qQ]$'){return}
 if($pr -notin @('38','39')){continue}
 $exe=Verify $pr
 Write-Host 'Browser viewport: 1 = 960x540; 2 = 640x360; 3 = 480x270.'
 Write-Host 'A smaller viewport can make webpage text larger at the same Terminal size.'
 $size=Read-Host 'Viewport (Enter = 640x360)'
 $dimensions=switch($size){'1'{@(960,540)} '3'{@(480,270)} default{@(640,360)}}
 Write-Host "Ready: PR$pr, $($dimensions[0])x$($dimensions[1]), input-focus fixture."
 Write-Host 'No assessment, automatic build, or automatic second browser session.'
 Write-Host 'Finish adjusting zoom now. Use Ctrl+Alt+Q to exit the browser.'
 $start=Read-Host 'Press Enter ONLY when ready to launch (or type B to return)'
 if($start){continue}
 $exe=Verify $pr
 $arguments="--fixture input-focus --width $($dimensions[0]) --height $($dimensions[1]) --fit contain --cell-aspect 0.5"
 $exitCode=[ManualASCIIomium]::Run($exe,$arguments)
 Write-Host "Browser exited with code $exitCode. Adjust zoom again or choose another revision."
}
