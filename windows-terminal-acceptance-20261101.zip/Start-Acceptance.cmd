@echo off
wt.exe -w new new-tab --title "ASCIIomium acceptance" -d "%~dp0." powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -NoExit -File "%~dp0acceptance\Run-Acceptance.ps1"
if errorlevel 1 pause
