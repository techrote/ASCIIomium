param([switch]$ValidateOnly)
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
$vs=& 'C:\Program Files (x86)\Microsoft Visual Studio\Installer\vswhere.exe' -latest -version '[17.0,18.0)' -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if(!$vs){throw 'VS2022 C++ tools missing'}
$bin=Join-Path $vs 'Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin'
$env:PATH="$bin;$env:PATH"
$cmake=Join-Path $bin 'cmake.exe'
$ctest=Join-Path $bin 'ctest.exe'
$cef=Join-Path $root 'third_party\cef\cef_binary_151.3.17+gf059e67+chromium-151.0.7922.138_windows64'
$targets=@(
 @{PR='38';SHA='5f8feccebeb0682890a2023a59b4c33e514c5497';Source=$root},
 @{PR='39';SHA='3aa9b9419dd7936d55bf6acb974f1b0d159f5d95';Source=(Join-Path $PSScriptRoot 'source-39')}
)
$keyboard=@(
 @('typing','Tab past five mapping buttons to Text; type ASCIIomium 123 !?; verify exact text.'),
 @('unicode','Enter accented, non-Latin and non-BMP text using keyboard/input method or terminal paste; verify and record method. Full IME composition is deferred.'),
 @('editing','Backspace/Delete/Insert/Escape and Enter in textarea: verify editing and diagnostic key events.'),
 @('navigation','Arrows, Home/End, PageUp/PageDown, Shift+arrows, Ctrl+arrows: verify caret, selection and scrolling.'),
 @('focus','Tab/Shift+Tab between controls; activate buttons/checkbox; switch away from Terminal and return, then type.'),
 @('modifiers','Ctrl+A/C/V using harmless text, Alt chords, modified navigation and F1-F12: inspect dispatch. Record Terminal-intercepted chords. Ctrl+C must not exit.'),
 @('quit','Exit with Ctrl+Alt+Q and verify clean shutdown.')
)
$mouse=@(
 @('centre-corners','Click CENTER and TL/TR/BL/BR; verify correct target for each.'),
 @('hover','Move over hover pad without a button; verify hover response and move events.'),
 @('press-release','Press/hold/drag/release left; exercise right/middle buttons; inspect separate down/up events and held-button flags.'),
 @('wheel','Wheel page up/down; verify movement/direction.'),
 @('horizontal-wheel','Exercise horizontal wheel if supported; otherwise Not tested.'),
 @('nested-scroll','Scroll to nested box; wheel inside for inner scroll, outside for page scroll.'),
 @('resize','Resize Terminal wide/tall/small/large; repeat centre/corner clicks and verify correct mapping.'),
 @('letterbox','Expose bars using wide/tall Terminal; click and wheel in bars; verify diagnostic rejection and no browser dispatch.'),
 @('mouse-modifiers','Ctrl/Alt clicks and wheel: inspect canonical and CEF modifier flags.'),
 @('shift-selection','Shift+drag selects Terminal text; verify selection bypass and no browser click/drag.'),
 @('keyboard-regression','Repeat ASCII/Unicode, Backspace/Delete, Tab/Shift+Tab, arrows and Ctrl+A/C/V; Ctrl+C must not exit.'),
 @('quit','Exit with Ctrl+Alt+Q and verify clean shutdown.')
)
function Verify($t) {
 $head=(& git -C $t.Source rev-parse HEAD).Trim()
 if($LASTEXITCODE -ne 0 -or $head -ne $t.SHA){throw "PR$($t.PR) revision mismatch: $head"}
 if((& git -C $t.Source status --porcelain --untracked-files=no)){throw "Tracked edits in $($t.Source)"}
}
foreach($t in $targets){Verify $t}
if($ValidateOnly){Write-Host 'Validated exact revisions, clean tracked files, VS2022 and bundled CMake.';return}
if(!$env:WT_SESSION){throw 'Use Start-Acceptance.cmd: genuine Windows Terminal required'}
$mutex=New-Object System.Threading.Mutex($false,'Local\ASCIIomiumPhysicalAcceptance')
try{$owned=$mutex.WaitOne(0)}catch [System.Threading.AbandonedMutexException]{$owned=$true}
if(!$owned){throw 'Another assessment is running. Finish or close it before restarting.'}
Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class AcceptanceConsole {
 public static int Run(string exe,string args,string debug) {
 var p=new System.Diagnostics.Process();
 p.StartInfo=new System.Diagnostics.ProcessStartInfo(exe,args);
 p.StartInfo.UseShellExecute=false;
 p.StartInfo.CreateNoWindow=false;
 p.StartInfo.RedirectStandardError=true;
 using(var log=System.IO.File.Create(debug)) {
 p.Start();var copy=p.StandardError.BaseStream.CopyToAsync(log);
 p.WaitForExit();copy.Wait();return p.ExitCode;
 }
 }
 [DllImport("kernel32.dll")] public static extern IntPtr GetStdHandle(int n);
 [DllImport("kernel32.dll")] public static extern bool GetConsoleMode(IntPtr h,out uint m);
 [DllImport("kernel32.dll")] public static extern uint GetConsoleCP();
 [DllImport("kernel32.dll")] public static extern uint GetConsoleOutputCP();
 public static string Snapshot() {
 uint i,o;if(!GetConsoleMode(GetStdHandle(-10),out i)||!GetConsoleMode(GetStdHandle(-11),out o))throw new Exception("Native console stdin/stdout required");
 return i+":"+o+":"+GetConsoleCP()+":"+GetConsoleOutputCP();
 }
}
'@
[AcceptanceConsole]::Snapshot() | Out-Null
$run=Join-Path $PSScriptRoot ('runs\'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N').Substring(0,6))
New-Item -ItemType Directory -Path $run -Force | Out-Null
$results=New-Object System.Collections.Generic.List[object]
foreach($t in $targets){
 $checks=if($t.PR -eq '38'){$keyboard}else{$mouse}
 foreach($c in $checks){$results.Add([pscustomobject]@{PR=$t.PR;Revision=$t.SHA;Check=$c[0];Instructions=$c[1];Status='Not tested';Notes=''})}
 $results.Add([pscustomobject]@{PR=$t.PR;Revision=$t.SHA;Check='restoration';Instructions='Verify original screen, visible cursor, normal colours, typing/editing, native selection and wheel after exit.';Status='Not tested';Notes=''})
}
function Save {
 $results | ConvertTo-Json -Depth 6 | Set-Content "$run\physical-results.json" -Encoding UTF8
 $results | Export-Csv "$run\physical-results.csv" -NoTypeInformation -Encoding UTF8
 $lines=@('# Physical acceptance', '',"Run: $run",'Operator observations only; automated tests are separate.','')
 foreach($row in $results){$lines+="- PR$($row.PR) $($row.Check): $($row.Status) | $($row.Notes)"}
 $lines | Set-Content "$run\REPORT.md" -Encoding UTF8
 Compress-Archive -Path "$run\*" -DestinationPath "$run.zip" -Force
}
function Logged($program,$arguments,$path) {
 & $program @arguments *> $path
 if($LASTEXITCODE -ne 0){throw "Command failed ($LASTEXITCODE): $path"}
}
Save
try {
 Copy-Item $PSCommandPath "$run\launcher.ps1"
 Copy-Item "$PSScriptRoot\setup" "$run\preparation" -Recurse
 & git --version | Set-Content "$run\environment.txt"
 & $cmake --version | Add-Content "$run\environment.txt"
 "WT_SESSION=$env:WT_SESSION; PowerShell=$($PSVersionTable.PSVersion); VS=$vs; CEF=$cef" | Add-Content "$run\environment.txt"
 foreach($t in $targets){
  Verify $t
  $pr=$t.PR
  $build=Join-Path $root "build-acceptance-$pr"
  Write-Host "PR$pr $($t.SHA): configure, Release build, CTest..."
  Logged $cmake @('-S',$t.Source,'-B',$build,'-G','Visual Studio 17 2022','-A','x64',"-DASCIIOMIUM_CEF_ROOT=$cef") "$run\configure-$pr.log"
  Logged $cmake @('--build',$build,'--config','Release','--parallel','4') "$run\build-$pr.log"
  Logged $ctest @('--test-dir',$build,'-C','Release','--output-on-failure') "$run\ctest-$pr.log"
  $rows=@($results | Where-Object PR -eq $pr)
  $guide="$run\PR$pr-guide.txt"
  @("PR$pr $($t.SHA)",'Only harmless input: raw typed bytes are logged.','Perform all steps then Ctrl+Alt+Q; report P/F/N afterwards.','If the first frame pauses, press Tab once. The unattended live probe stalled without physical input; report any continued freeze as Fail.','') | Set-Content $guide -Encoding UTF8
  foreach($row in $rows){"$($row.Check): $($row.Instructions)" | Add-Content $guide -Encoding UTF8}
  Get-Content $guide | ForEach-Object {Write-Host $_}
  Start-Process notepad.exe -ArgumentList ('"'+$guide+'"')
  Read-Host 'Guide is in Notepad. Press Enter to start'
  Verify $t
  $before=[AcceptanceConsole]::Snapshot()
  $exe=Join-Path $build 'bin\RELEASE\asciiomium_live.exe'
  # Only stderr is captured. Native console stdin/stdout are inherited, never piped.
  $arguments='--fixture input-focus --width 960 --height 540 --fit contain --cell-aspect 0.5 --input-debug --geometry-debug --report "'+$run+'\live-'+$pr+'.json"'
  "$exe $arguments" | Set-Content "$run\command-$pr.txt"
  $exit=[AcceptanceConsole]::Run($exe,$arguments,"$run\input-debug-$pr.log")
  $after=[AcceptanceConsole]::Snapshot()
  [pscustomobject]@{Revision=$t.SHA;ExitCode=$exit;Before=$before;After=$after;ModesAndCodePagesRestored=($before -eq $after)} | ConvertTo-Json | Set-Content "$run\console-$pr.json"
  Write-Host "Exit=$exit; console modes/code pages restored: $($before -eq $after)"
  foreach($row in $rows){
   Write-Host "$($row.Check): $($row.Instructions)"
   do{$answer=(Read-Host 'P=Pass / F=Fail / N=Not tested (Enter=N)').Trim().ToUpper()}while($answer -notin @('P','F','N',''))
   $row.Status=switch($answer){'P'{'Pass'} 'F'{'Fail'} default{'Not tested'}}
   $row.Notes=Read-Host 'Observation / concise failure note / reason not tested (Enter to skip)'
   while($row.Status -eq 'Fail' -and !$row.Notes){$row.Notes=Read-Host 'Failure note required'}
   if($row.Check -eq 'restoration' -and ($before -ne $after -or $exit -ne 0)){$row.Status='Fail';$row.Notes+=' Console mismatch or nonzero exit.'}
   Save
  }
 }
} catch {
 $_ | Out-String | Set-Content "$run\ERROR.txt"
 Write-Host "Interrupted: $_" -ForegroundColor Red
} finally {
 Save
 $mutex.ReleaseMutex()
 $mutex.Dispose()
 Write-Host "Evidence: $run"
 Write-Host "ZIP: $run.zip"
 Write-Host 'Restart creates a fresh attempt; prior evidence and partial results are preserved.'
}
